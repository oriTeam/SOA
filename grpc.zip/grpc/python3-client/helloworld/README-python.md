To run Server or Client in Python:

Run GRPC Python Server:

  $ cd grpcDemo/grpc-python/helloworld
  $ python greeter_server.py
  
Run GRPC Python Client:
  $ cd grpcDemo/grpc-python/helloworld
  $ python greeter_client.py
  
